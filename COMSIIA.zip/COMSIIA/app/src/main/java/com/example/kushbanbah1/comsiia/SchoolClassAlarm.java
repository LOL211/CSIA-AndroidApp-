package com.example.kushbanbah1.comsiia;

public class SchoolClassAlarm {
    int date;
    int day_1_2;
    boolean enabled; //alarms enbaled or not

    //data structure used to store and use for daily alarm functions
}
